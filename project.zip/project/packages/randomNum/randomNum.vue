<template>
  <div class="codeY">
    <input type="text" v-model="value">
    <button @click="getNum">生成随机数</button>
  </div>
</template>
<script>
export default {
  name: "randomNum",
  data() {
    return {
      value: 0
    }
  },
  mounted() {
    
  },
  methods: {
    getNum(){
      this.value = Math.random() * 140000000000
    }
  }
}
</script>
<style lang='scss'>
.codeY {
    input {
        display: block;
        width: 290px;
        line-height: 40px;
        margin: 10px 0;
        padding: 0 10px;
        outline: none;
        border: 1px solid #c8cccf;
        border-radius: 4px;
        color: #6a6f77;
    }
}
</style>
