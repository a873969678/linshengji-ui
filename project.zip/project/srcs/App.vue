<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png" />
    <h1>组件1</h1>
    <verdistcode class="codes" :width="300" :height="150" :success="success" />
    <input v-model="value" type="text" />
    <span>文字占位位长度：{{this.length}}</span>
    <h1>组件2</h1>
    <randomNum class="randomNum" />
  </div>
</template>

<script>
import { getTextLength } from "gettextlength";
import Vue from 'vue';
import { verdistcode } from 'verdistcode';
Vue.use(verdistcode)
export default {
  name: "app",
  data() {
    return {
      value: ""
    };
  },
  computed: {
    length() {
      return getTextLength(this.value);
    }
  },
  methods: {
    success(type) {
      this.value = String(type)
    }
  }
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.codes{
  margin: 0 auto;
}
.randomNum{
  margin: 0 auto;
  width: 300px;
}
</style>
