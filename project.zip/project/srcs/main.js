import Vue from 'vue'
import App from './App.vue'
import demo from '../packages/index'
// import demo from 'verdistcode'
// import 'verdistcode/lib/demo.css'
// 注册组件库
Vue.use(demo)
Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
